<?php return array (
  'charge-calculator' => 'App\\Http\\Livewire\\ChargeCalculator',
  'live-cart' => 'App\\Http\\Livewire\\LiveCart',
  'payment-calculator' => 'App\\Http\\Livewire\\PaymentCalculator',
  'slugify' => 'App\\Http\\Livewire\\Slugify',
);