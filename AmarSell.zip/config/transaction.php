<?php

return [
    'ways' => [
        'Bank',
        'bKash',
        'Rocket',
    ]
];