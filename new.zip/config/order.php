<?php

return [
    'statuses' => [
        'pending',
        'processing',
        'shipping',
        'completed',
        'returned',
    ],
];