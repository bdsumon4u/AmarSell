@extends('reseller.layout')

@section('content')
@include('earnings')
@endsection