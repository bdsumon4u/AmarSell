@extends('layouts.ready')
@include('order.invoice')