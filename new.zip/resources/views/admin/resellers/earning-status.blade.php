@extends('layouts.ready')

@section('content')
@include('earnings')
@endsection